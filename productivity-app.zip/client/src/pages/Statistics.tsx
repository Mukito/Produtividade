import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BarChart3, TrendingUp, CheckCircle2, Clock } from "lucide-react";
import { useMemo } from "react";

export default function Statistics() {
  const { user } = useAuth();
  const { data: tasks, isLoading: tasksLoading } = trpc.tasks.list.useQuery();
  const { data: stats, isLoading: statsLoading } = trpc.statistics.tasks.useQuery();
  const { data: events, isLoading: eventsLoading } = trpc.events.list.useQuery();

  // Calcular estatísticas adicionais
  const taskStats = useMemo(() => {
    if (!tasks) return null;

    const now = new Date();
    const thisWeek = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7);
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const completedThisWeek = tasks.filter(
      t => t.status === 'completed' && t.completedAt && new Date(t.completedAt) >= thisWeek
    ).length;

    const completedThisMonth = tasks.filter(
      t => t.status === 'completed' && t.completedAt && new Date(t.completedAt) >= thisMonth
    ).length;

    const overdueTasks = tasks.filter(
      t => t.status === 'pending' && t.dueDate && new Date(t.dueDate) < now
    ).length;

    const completionRate = tasks.length > 0 
      ? Math.round((tasks.filter(t => t.status === 'completed').length / tasks.length) * 100)
      : 0;

    return {
      completedThisWeek,
      completedThisMonth,
      overdueTasks,
      completionRate,
    };
  }, [tasks]);

  // Dados para gráfico de barras (tarefas por prioridade)
  const priorityData = useMemo(() => {
    if (!tasks) return [];
    
    const priorities = {
      high: { label: 'Alta', pending: 0, completed: 0, color: 'rgb(239, 68, 68)' },
      medium: { label: 'Média', pending: 0, completed: 0, color: 'rgb(234, 179, 8)' },
      low: { label: 'Baixa', pending: 0, completed: 0, color: 'rgb(59, 130, 246)' },
    };

    tasks.forEach(task => {
      if (task.status === 'completed') {
        priorities[task.priority].completed++;
      } else {
        priorities[task.priority].pending++;
      }
    });

    return Object.entries(priorities).map(([key, value]) => ({
      priority: value.label,
      pending: value.pending,
      completed: value.completed,
      total: value.pending + value.completed,
      color: value.color,
    }));
  }, [tasks]);

  // Dados para gráfico de linha (produtividade nos últimos 7 dias)
  const weeklyProductivity = useMemo(() => {
    if (!tasks) return [];

    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      return date;
    });

    return last7Days.map(date => {
      const dateStr = date.toISOString().split('T')[0];
      const completed = tasks.filter(t => 
        t.completedAt && new Date(t.completedAt).toISOString().split('T')[0] === dateStr
      ).length;

      return {
        date: date.toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: '2-digit' }),
        completed,
      };
    });
  }, [tasks]);

  const maxCompleted = Math.max(...weeklyProductivity.map(d => d.completed), 1);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Estatísticas</h1>
          <p className="text-muted-foreground mt-2">
            Acompanhe seu desempenho e produtividade
          </p>
        </div>

        {/* Cards de Métricas Principais */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card className="bg-card text-card-foreground">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Taxa de Conclusão</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{taskStats?.completionRate || 0}%</div>
              <p className="text-xs text-muted-foreground mt-1">
                De todas as tarefas
              </p>
            </CardContent>
          </Card>

          <Card className="bg-card text-card-foreground">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Concluídas Esta Semana</CardTitle>
              <CheckCircle2 className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{taskStats?.completedThisWeek || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Últimos 7 dias
              </p>
            </CardContent>
          </Card>

          <Card className="bg-card text-card-foreground">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Concluídas Este Mês</CardTitle>
              <BarChart3 className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{taskStats?.completedThisMonth || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Mês atual
              </p>
            </CardContent>
          </Card>

          <Card className="bg-card text-card-foreground">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tarefas Atrasadas</CardTitle>
              <Clock className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{taskStats?.overdueTasks || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Vencidas e pendentes
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Gráficos */}
        <div className="grid gap-4 md:grid-cols-2">
          {/* Gráfico de Barras - Tarefas por Prioridade */}
          <Card className="bg-card text-card-foreground">
            <CardHeader>
              <CardTitle>Tarefas por Prioridade</CardTitle>
              <CardDescription>Distribuição de tarefas pendentes e concluídas</CardDescription>
            </CardHeader>
            <CardContent>
              {tasksLoading ? (
                <p className="text-sm text-muted-foreground">Carregando...</p>
              ) : priorityData.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nenhum dado disponível</p>
              ) : (
                <div className="space-y-4">
                  {priorityData.map((item) => {
                    const maxValue = Math.max(...priorityData.map(d => d.total), 1);
                    const pendingWidth = (item.pending / maxValue) * 100;
                    const completedWidth = (item.completed / maxValue) * 100;

                    return (
                      <div key={item.priority} className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-medium text-foreground">{item.priority}</span>
                          <span className="text-muted-foreground">
                            {item.total} {item.total === 1 ? 'tarefa' : 'tarefas'}
                          </span>
                        </div>
                        <div className="flex gap-1 h-8 rounded-lg overflow-hidden bg-muted/30">
                          {item.pending > 0 && (
                            <div
                              className="bg-yellow-500/60 flex items-center justify-center text-xs font-medium text-white"
                              style={{ width: `${pendingWidth}%` }}
                            >
                              {item.pending > 0 && item.pending}
                            </div>
                          )}
                          {item.completed > 0 && (
                            <div
                              className="bg-green-500/60 flex items-center justify-center text-xs font-medium text-white"
                              style={{ width: `${completedWidth}%` }}
                            >
                              {item.completed > 0 && item.completed}
                            </div>
                          )}
                        </div>
                        <div className="flex gap-4 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <div className="w-3 h-3 rounded bg-yellow-500/60" />
                            Pendentes: {item.pending}
                          </span>
                          <span className="flex items-center gap-1">
                            <div className="w-3 h-3 rounded bg-green-500/60" />
                            Concluídas: {item.completed}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Gráfico de Linha - Produtividade Semanal */}
          <Card className="bg-card text-card-foreground">
            <CardHeader>
              <CardTitle>Produtividade Semanal</CardTitle>
              <CardDescription>Tarefas concluídas nos últimos 7 dias</CardDescription>
            </CardHeader>
            <CardContent>
              {tasksLoading ? (
                <p className="text-sm text-muted-foreground">Carregando...</p>
              ) : weeklyProductivity.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nenhum dado disponível</p>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-end justify-between gap-2 h-48">
                    {weeklyProductivity.map((day, index) => {
                      const height = (day.completed / maxCompleted) * 100;
                      return (
                        <div key={index} className="flex-1 flex flex-col items-center gap-2">
                          <div className="relative w-full flex items-end justify-center" style={{ height: '160px' }}>
                            <div
                              className="w-full bg-primary/80 rounded-t-lg transition-all hover:bg-primary flex items-end justify-center pb-1"
                              style={{ height: `${height}%`, minHeight: day.completed > 0 ? '20px' : '0' }}
                            >
                              {day.completed > 0 && (
                                <span className="text-xs font-medium text-primary-foreground">
                                  {day.completed}
                                </span>
                              )}
                            </div>
                          </div>
                          <span className="text-xs text-muted-foreground text-center">
                            {day.date}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                  <div className="pt-4 border-t border-border">
                    <p className="text-sm text-muted-foreground">
                      Total de tarefas concluídas esta semana: <span className="font-semibold text-foreground">{taskStats?.completedThisWeek || 0}</span>
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Resumo Geral */}
        <Card className="bg-card text-card-foreground">
          <CardHeader>
            <CardTitle>Resumo Geral</CardTitle>
            <CardDescription>Visão completa da sua produtividade</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Total de Tarefas</p>
                <p className="text-2xl font-bold text-foreground">{stats?.total || 0}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Tarefas Concluídas</p>
                <p className="text-2xl font-bold text-green-500">{stats?.completed || 0}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Tarefas Pendentes</p>
                <p className="text-2xl font-bold text-yellow-500">{stats?.pending || 0}</p>
              </div>
            </div>
            <div className="mt-6 pt-6 border-t border-border">
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Prioridade Alta</p>
                  <p className="text-xl font-semibold text-red-400">
                    {stats?.byPriority?.find(p => p.priority === 'high')?.count || 0}
                  </p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Prioridade Média</p>
                  <p className="text-xl font-semibold text-yellow-400">
                    {stats?.byPriority?.find(p => p.priority === 'medium')?.count || 0}
                  </p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Prioridade Baixa</p>
                  <p className="text-xl font-semibold text-blue-400">
                    {stats?.byPriority?.find(p => p.priority === 'low')?.count || 0}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
