# TaskFlow - Documentação do Aplicativo de Produtividade

## Visão Geral

**TaskFlow** é um aplicativo profissional de produtividade desenvolvido com arquitetura full-stack moderna, oferecendo gerenciamento completo de tarefas, agenda de eventos e visualização de estatísticas de desempenho.

## Tecnologias Utilizadas

### Backend
- **Node.js** com **Express 4** - Servidor web robusto
- **tRPC 11** - API type-safe com contratos end-to-end
- **Drizzle ORM** - ORM moderno para MySQL/TiDB
- **MySQL/TiDB** - Banco de dados relacional
- **JWT** - Autenticação segura com tokens
- **Manus OAuth** - Sistema de autenticação integrado

### Frontend
- **React 19** - Biblioteca UI moderna
- **Tailwind CSS 4** - Framework CSS utility-first
- **shadcn/ui** - Componentes UI acessíveis e customizáveis
- **Wouter** - Roteamento leve
- **Superjson** - Serialização de dados complexos (Date, etc)

## Arquitetura do Sistema

### Estrutura de Pastas

```
productivity-app/
├── client/                 # Frontend React
│   ├── src/
│   │   ├── pages/         # Páginas da aplicação
│   │   │   ├── Dashboard.tsx
│   │   │   ├── Tasks.tsx
│   │   │   ├── Calendar.tsx
│   │   │   └── Statistics.tsx
│   │   ├── components/    # Componentes reutilizáveis
│   │   ├── lib/           # Configurações (tRPC)
│   │   └── App.tsx        # Rotas principais
├── server/                # Backend Node.js
│   ├── routers.ts         # Definição de rotas tRPC
│   ├── db.ts              # Queries do banco de dados
│   └── _core/             # Configurações do servidor
├── drizzle/               # Schema e migrações do banco
│   └── schema.ts          # Definição das tabelas
└── shared/                # Tipos e constantes compartilhadas
```

## Banco de Dados

### Tabelas

#### 1. **users** - Usuários do Sistema
- `id` (INT, PK) - Identificador único
- `openId` (VARCHAR) - ID OAuth do Manus
- `name` (TEXT) - Nome do usuário
- `email` (VARCHAR) - Email do usuário
- `role` (ENUM) - Papel: 'user' ou 'admin'
- `createdAt`, `updatedAt`, `lastSignedIn` (TIMESTAMP)

#### 2. **categories** - Categorias Personalizadas
- `id` (INT, PK) - Identificador único
- `userId` (INT) - Referência ao usuário
- `name` (VARCHAR) - Nome da categoria
- `color` (VARCHAR) - Cor em hexadecimal (#3b82f6)
- `createdAt`, `updatedAt` (TIMESTAMP)

#### 3. **tasks** - Tarefas do Usuário
- `id` (INT, PK) - Identificador único
- `userId` (INT) - Referência ao usuário
- `categoryId` (INT, nullable) - Categoria da tarefa
- `title` (VARCHAR) - Título da tarefa
- `description` (TEXT, nullable) - Descrição detalhada
- `status` (ENUM) - 'pending' ou 'completed'
- `priority` (ENUM) - 'low', 'medium' ou 'high'
- `dueDate` (TIMESTAMP, nullable) - Data de vencimento
- `completedAt` (TIMESTAMP, nullable) - Data de conclusão
- `createdAt`, `updatedAt` (TIMESTAMP)

#### 4. **events** - Eventos da Agenda
- `id` (INT, PK) - Identificador único
- `userId` (INT) - Referência ao usuário
- `categoryId` (INT, nullable) - Categoria do evento
- `title` (VARCHAR) - Título do evento
- `description` (TEXT, nullable) - Descrição do evento
- `startDate` (TIMESTAMP) - Data/hora de início
- `endDate` (TIMESTAMP) - Data/hora de término
- `location` (VARCHAR, nullable) - Local do evento
- `createdAt`, `updatedAt` (TIMESTAMP)

## API Backend (tRPC)

### Endpoints de Autenticação
- `auth.me` - Retorna dados do usuário autenticado
- `auth.logout` - Realiza logout do usuário

### Endpoints de Categorias
- `categories.list` - Lista todas as categorias do usuário
- `categories.create` - Cria nova categoria
- `categories.update` - Atualiza categoria existente
- `categories.delete` - Exclui categoria

### Endpoints de Tarefas
- `tasks.list` - Lista todas as tarefas do usuário
- `tasks.create` - Cria nova tarefa
- `tasks.update` - Atualiza tarefa (incluindo status)
- `tasks.delete` - Exclui tarefa

### Endpoints de Eventos
- `events.list` - Lista todos os eventos do usuário
- `events.create` - Cria novo evento
- `events.update` - Atualiza evento existente
- `events.delete` - Exclui evento

### Endpoints de Estatísticas
- `statistics.tasks` - Retorna estatísticas de tarefas (total, concluídas, pendentes, por prioridade)

## Funcionalidades Principais

### 1. Dashboard
**Rota:** `/`

Página inicial com visão geral da produtividade:
- Cards com métricas principais (total, pendentes, concluídas, eventos futuros)
- Lista das 5 tarefas pendentes mais recentes
- Lista dos 5 próximos eventos agendados
- Indicadores visuais de prioridade e status

### 2. Gerenciamento de Tarefas
**Rota:** `/tasks`

Sistema completo de gerenciamento de tarefas:
- **Criar Tarefa:** Formulário com título, descrição, prioridade e data de vencimento
- **Editar Tarefa:** Atualização de qualquer campo da tarefa
- **Excluir Tarefa:** Remoção com confirmação
- **Marcar como Concluída:** Toggle rápido de status
- **Filtros:** Por status (todas/pendentes/concluídas) e prioridade (todas/baixa/média/alta)
- **Prioridades Visuais:** Cores distintas para alta (vermelho), média (amarelo) e baixa (azul)

### 3. Agenda e Calendário
**Rota:** `/calendar`

Visualização e gerenciamento de eventos:
- **Calendário Mensal:** Grid interativo com navegação entre meses
- **Criar Evento:** Clique em qualquer dia ou botão "Novo Evento"
- **Formulário Completo:** Título, descrição, data/hora início e fim, local
- **Visualização de Eventos:** Até 2 eventos por dia no calendário, com indicador de "mais"
- **Lista de Próximos Eventos:** 10 eventos futuros ordenados por data
- **Editar/Excluir:** Ações diretas na lista de eventos
- **Destaque do Dia Atual:** Borda azul no dia corrente

### 4. Estatísticas e Gráficos
**Rota:** `/statistics`

Análise completa de produtividade:

#### Métricas Principais
- **Taxa de Conclusão:** Percentual de tarefas concluídas
- **Concluídas Esta Semana:** Últimos 7 dias
- **Concluídas Este Mês:** Mês atual
- **Tarefas Atrasadas:** Pendentes com data vencida

#### Gráficos
1. **Tarefas por Prioridade:**
   - Gráfico de barras horizontais
   - Separação visual entre pendentes (amarelo) e concluídas (verde)
   - Contadores individuais por prioridade

2. **Produtividade Semanal:**
   - Gráfico de barras verticais
   - Últimos 7 dias de atividade
   - Altura proporcional ao número de tarefas concluídas

3. **Resumo Geral:**
   - Total de tarefas, concluídas e pendentes
   - Distribuição por prioridade (alta, média, baixa)

## Segurança

### Controle de Acesso
- **Autenticação Obrigatória:** Todas as rotas protegidas requerem login
- **Isolamento de Dados:** Cada usuário acessa apenas seus próprios dados
- **Validação Backend:** Todas as entradas são validadas no servidor
- **Proteção de Rotas:** `protectedProcedure` garante autenticação em todas as operações

### Validações
- **Campos Obrigatórios:** Título para tarefas e eventos
- **Datas Consistentes:** Validação de data de término posterior à de início
- **Sanitização:** Dados tratados antes de salvar no banco
- **Tratamento de Erros:** Mensagens claras e informativas via toast

## Como Usar

### Primeiro Acesso
1. Acesse o aplicativo e clique em "Sign In"
2. Faça login com sua conta Manus OAuth
3. Você será redirecionado para o Dashboard

### Criando Tarefas
1. Navegue até "Tarefas" no menu lateral
2. Clique em "Nova Tarefa"
3. Preencha o formulário:
   - **Título:** Nome da tarefa (obrigatório)
   - **Descrição:** Detalhes adicionais (opcional)
   - **Prioridade:** Baixa, Média ou Alta
   - **Data de Vencimento:** Quando deve ser concluída (opcional)
4. Clique em "Criar"

### Gerenciando Tarefas
- **Concluir:** Clique no círculo à esquerda da tarefa
- **Editar:** Clique no ícone de lápis
- **Excluir:** Clique no ícone de lixeira (confirmação necessária)
- **Filtrar:** Use os seletores de Status e Prioridade

### Criando Eventos
1. Navegue até "Agenda" no menu lateral
2. Clique em um dia no calendário OU clique em "Novo Evento"
3. Preencha o formulário:
   - **Título:** Nome do evento (obrigatório)
   - **Descrição:** Detalhes do evento (opcional)
   - **Data/Hora Início:** Quando começa (obrigatório)
   - **Data/Hora Término:** Quando termina (obrigatório)
   - **Local:** Onde será realizado (opcional)
4. Clique em "Criar"

### Visualizando Estatísticas
1. Navegue até "Estatísticas" no menu lateral
2. Visualize suas métricas de produtividade
3. Analise os gráficos de desempenho
4. Identifique padrões e áreas de melhoria

## Design e Interface

### Tema
- **Tema Escuro Profissional:** Fundo escuro com acentos azuis
- **Cores Semânticas:** 
  - Azul (#3b82f6) - Principal/Primário
  - Verde - Sucesso/Concluído
  - Amarelo - Atenção/Pendente
  - Vermelho - Urgente/Erro
- **Tipografia:** Sistema de fontes nativo (sans-serif)
- **Espaçamento:** Grid responsivo com breakpoints mobile/tablet/desktop

### Responsividade
- **Mobile First:** Design otimizado para dispositivos móveis
- **Breakpoints:**
  - Mobile: < 640px
  - Tablet: 640px - 1024px
  - Desktop: > 1024px
- **Sidebar Colapsável:** Menu lateral se adapta ao tamanho da tela

## Comandos de Desenvolvimento

### Instalação
```bash
cd productivity-app
pnpm install
```

### Desenvolvimento
```bash
pnpm dev
# Servidor disponível em http://localhost:3000
```

### Banco de Dados
```bash
# Aplicar migrações
pnpm db:push

# Gerar nova migração
pnpm db:generate
```

### Build para Produção
```bash
pnpm build
```

## Variáveis de Ambiente

As seguintes variáveis são automaticamente injetadas pelo sistema Manus:

- `DATABASE_URL` - String de conexão MySQL/TiDB
- `JWT_SECRET` - Segredo para assinatura de tokens
- `VITE_APP_ID` - ID da aplicação OAuth
- `OAUTH_SERVER_URL` - URL do servidor OAuth
- `VITE_OAUTH_PORTAL_URL` - URL do portal de login
- `OWNER_OPEN_ID`, `OWNER_NAME` - Informações do proprietário
- `VITE_APP_TITLE` - Título do aplicativo
- `VITE_APP_LOGO` - Logo do aplicativo

## Suporte e Manutenção

### Logs
- Logs do servidor disponíveis no console de desenvolvimento
- Erros de TypeScript mostrados em tempo real
- Mensagens de erro exibidas via toast no frontend

### Backup
- Dados armazenados no banco MySQL/TiDB
- Recomenda-se backup regular do banco de dados
- Checkpoints do projeto podem ser criados via interface Manus

### Escalabilidade
- Arquitetura preparada para crescimento
- Banco de dados relacional escalável
- API type-safe reduz bugs em produção
- Componentes reutilizáveis facilitam manutenção

## Recursos Futuros (Roadmap)

- Sistema de categorias personalizadas no frontend
- Notificações de tarefas vencendo
- Exportação de dados (PDF, CSV)
- Integração com calendários externos
- Modo de visualização semanal/diária
- Compartilhamento de tarefas entre usuários
- Anexos em tarefas e eventos
- Comentários e histórico de alterações
- Temas customizáveis
- Aplicativo mobile nativo

## Conclusão

**TaskFlow** é um aplicativo completo e profissional de produtividade, desenvolvido com as melhores práticas de desenvolvimento web moderno. A arquitetura type-safe, autenticação segura e interface intuitiva garantem uma experiência de usuário excepcional para gerenciamento de tarefas e eventos.

Para suporte adicional ou dúvidas, consulte a documentação do código ou entre em contato com o desenvolvedor.

---

**Desenvolvido com ❤️ usando React, Node.js e tRPC**
