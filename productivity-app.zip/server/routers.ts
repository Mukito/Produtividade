import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Routers de funcionalidades
  categories: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const { getUserCategories } = await import('./db');
      return getUserCategories(ctx.user.id);
    }),
    create: protectedProcedure
      .input((raw: unknown) => {
        const data = raw as { name: string; color?: string };
        if (!data.name) throw new Error('Nome é obrigatório');
        return data;
      })
      .mutation(async ({ ctx, input }) => {
        const { createCategory } = await import('./db');
        return createCategory({
          userId: ctx.user.id,
          name: input.name,
          color: input.color || '#3b82f6',
        });
      }),
    update: protectedProcedure
      .input((raw: unknown) => {
        const data = raw as { id: number; name?: string; color?: string };
        if (!data.id) throw new Error('ID é obrigatório');
        return data;
      })
      .mutation(async ({ ctx, input }) => {
        const { updateCategory } = await import('./db');
        const { id, ...updates } = input;
        return updateCategory(id, ctx.user.id, updates);
      }),
    delete: protectedProcedure
      .input((raw: unknown) => {
        const data = raw as { id: number };
        if (!data.id) throw new Error('ID é obrigatório');
        return data;
      })
      .mutation(async ({ ctx, input }) => {
        const { deleteCategory } = await import('./db');
        return deleteCategory(input.id, ctx.user.id);
      }),
  }),

  tasks: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const { getUserTasks } = await import('./db');
      return getUserTasks(ctx.user.id);
    }),
    create: protectedProcedure
      .input((raw: unknown) => {
        const data = raw as {
          title: string;
          description?: string;
          categoryId?: number;
          priority?: 'low' | 'medium' | 'high';
          dueDate?: Date;
        };
        if (!data.title) throw new Error('Título é obrigatório');
        return data;
      })
      .mutation(async ({ ctx, input }) => {
        const { createTask } = await import('./db');
        return createTask({
          userId: ctx.user.id,
          title: input.title,
          description: input.description,
          categoryId: input.categoryId,
          priority: input.priority || 'medium',
          dueDate: input.dueDate,
          status: 'pending',
        });
      }),
    update: protectedProcedure
      .input((raw: unknown) => {
        const data = raw as {
          id: number;
          title?: string;
          description?: string;
          categoryId?: number;
          priority?: 'low' | 'medium' | 'high';
          status?: 'pending' | 'completed';
          dueDate?: Date;
        };
        if (!data.id) throw new Error('ID é obrigatório');
        return data;
      })
      .mutation(async ({ ctx, input }) => {
        const { updateTask } = await import('./db');
        const { id, ...updates } = input;
        if (updates.status === 'completed') {
          (updates as any).completedAt = new Date();
        }
        return updateTask(id, ctx.user.id, updates);
      }),
    delete: protectedProcedure
      .input((raw: unknown) => {
        const data = raw as { id: number };
        if (!data.id) throw new Error('ID é obrigatório');
        return data;
      })
      .mutation(async ({ ctx, input }) => {
        const { deleteTask } = await import('./db');
        return deleteTask(input.id, ctx.user.id);
      }),
  }),

  events: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const { getUserEvents } = await import('./db');
      return getUserEvents(ctx.user.id);
    }),
    create: protectedProcedure
      .input((raw: unknown) => {
        const data = raw as {
          title: string;
          description?: string;
          categoryId?: number;
          startDate: Date;
          endDate: Date;
          location?: string;
        };
        if (!data.title) throw new Error('Título é obrigatório');
        if (!data.startDate || !data.endDate) throw new Error('Datas são obrigatórias');
        return data;
      })
      .mutation(async ({ ctx, input }) => {
        const { createEvent } = await import('./db');
        return createEvent({
          userId: ctx.user.id,
          title: input.title,
          description: input.description,
          categoryId: input.categoryId,
          startDate: input.startDate,
          endDate: input.endDate,
          location: input.location,
        });
      }),
    update: protectedProcedure
      .input((raw: unknown) => {
        const data = raw as {
          id: number;
          title?: string;
          description?: string;
          categoryId?: number;
          startDate?: Date;
          endDate?: Date;
          location?: string;
        };
        if (!data.id) throw new Error('ID é obrigatório');
        return data;
      })
      .mutation(async ({ ctx, input }) => {
        const { updateEvent } = await import('./db');
        const { id, ...updates } = input;
        return updateEvent(id, ctx.user.id, updates);
      }),
    delete: protectedProcedure
      .input((raw: unknown) => {
        const data = raw as { id: number };
        if (!data.id) throw new Error('ID é obrigatório');
        return data;
      })
      .mutation(async ({ ctx, input }) => {
        const { deleteEvent } = await import('./db');
        return deleteEvent(input.id, ctx.user.id);
      }),
  }),

  statistics: router({
    tasks: protectedProcedure.query(async ({ ctx }) => {
      const { getTaskStatistics } = await import('./db');
      return getTaskStatistics(ctx.user.id);
    }),
  }),
});

export type AppRouter = typeof appRouter;
